﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblTickets = New System.Windows.Forms.Label()
        Me.txtNumberOFTIckets = New System.Windows.Forms.TextBox()
        Me.LblPrice = New System.Windows.Forms.Label()
        Me.txtPriceOfTickets = New System.Windows.Forms.TextBox()
        Me.LblSubtotal = New System.Windows.Forms.Label()
        Me.LblTax = New System.Windows.Forms.Label()
        Me.LblTotal = New System.Windows.Forms.Label()
        Me.LblDailyGrandTotal = New System.Windows.Forms.Label()
        Me.LblPromotersProfit = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnSubmit
        '
        Me.btnSubmit.Location = New System.Drawing.Point(203, 294)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(75, 23)
        Me.btnSubmit.TabIndex = 0
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(325, 294)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 1
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(446, 294)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 2
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblTickets
        '
        Me.lblTickets.AutoSize = True
        Me.lblTickets.Location = New System.Drawing.Point(217, 113)
        Me.lblTickets.Name = "lblTickets"
        Me.lblTickets.Size = New System.Drawing.Size(90, 13)
        Me.lblTickets.TabIndex = 3
        Me.lblTickets.Text = "NumberOfTickets"
        '
        'txtNumberOFTIckets
        '
        Me.txtNumberOFTIckets.Location = New System.Drawing.Point(313, 110)
        Me.txtNumberOFTIckets.Name = "txtNumberOFTIckets"
        Me.txtNumberOFTIckets.Size = New System.Drawing.Size(100, 20)
        Me.txtNumberOFTIckets.TabIndex = 4
        '
        'LblPrice
        '
        Me.LblPrice.AutoSize = True
        Me.LblPrice.Location = New System.Drawing.Point(246, 140)
        Me.LblPrice.Name = "LblPrice"
        Me.LblPrice.Size = New System.Drawing.Size(61, 13)
        Me.LblPrice.TabIndex = 5
        Me.LblPrice.Text = "TicketPrice"
        '
        'txtPriceOfTickets
        '
        Me.txtPriceOfTickets.Location = New System.Drawing.Point(313, 137)
        Me.txtPriceOfTickets.Name = "txtPriceOfTickets"
        Me.txtPriceOfTickets.Size = New System.Drawing.Size(100, 20)
        Me.txtPriceOfTickets.TabIndex = 6
        '
        'LblSubtotal
        '
        Me.LblSubtotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblSubtotal.Location = New System.Drawing.Point(345, 160)
        Me.LblSubtotal.Name = "LblSubtotal"
        Me.LblSubtotal.Size = New System.Drawing.Size(41, 13)
        Me.LblSubtotal.TabIndex = 7
        '
        'LblTax
        '
        Me.LblTax.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblTax.Location = New System.Drawing.Point(345, 183)
        Me.LblTax.Name = "LblTax"
        Me.LblTax.Size = New System.Drawing.Size(39, 13)
        Me.LblTax.TabIndex = 8
        '
        'LblTotal
        '
        Me.LblTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblTotal.Location = New System.Drawing.Point(345, 205)
        Me.LblTotal.Name = "LblTotal"
        Me.LblTotal.Size = New System.Drawing.Size(39, 13)
        Me.LblTotal.TabIndex = 9
        '
        'LblDailyGrandTotal
        '
        Me.LblDailyGrandTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblDailyGrandTotal.Location = New System.Drawing.Point(345, 227)
        Me.LblDailyGrandTotal.Name = "LblDailyGrandTotal"
        Me.LblDailyGrandTotal.Size = New System.Drawing.Size(39, 13)
        Me.LblDailyGrandTotal.TabIndex = 10
        '
        'LblPromotersProfit
        '
        Me.LblPromotersProfit.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblPromotersProfit.Location = New System.Drawing.Point(345, 250)
        Me.LblPromotersProfit.Name = "LblPromotersProfit"
        Me.LblPromotersProfit.Size = New System.Drawing.Size(39, 13)
        Me.LblPromotersProfit.TabIndex = 11
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(772, 637)
        Me.Controls.Add(Me.LblPromotersProfit)
        Me.Controls.Add(Me.LblDailyGrandTotal)
        Me.Controls.Add(Me.LblTotal)
        Me.Controls.Add(Me.LblTax)
        Me.Controls.Add(Me.LblSubtotal)
        Me.Controls.Add(Me.txtPriceOfTickets)
        Me.Controls.Add(Me.LblPrice)
        Me.Controls.Add(Me.txtNumberOFTIckets)
        Me.Controls.Add(Me.lblTickets)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnSubmit)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnSubmit As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblTickets As Label
    Friend WithEvents txtNumberOFTIckets As TextBox
    Friend WithEvents LblPrice As Label
    Friend WithEvents txtPriceOfTickets As TextBox
    Friend WithEvents LblSubtotal As Label
    Friend WithEvents LblTax As Label
    Friend WithEvents LblTotal As Label
    Friend WithEvents LblDailyGrandTotal As Label
    Friend WithEvents LblPromotersProfit As Label
End Class
