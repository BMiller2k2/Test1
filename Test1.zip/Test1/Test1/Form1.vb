﻿Public Class Form1
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim dblSubtotalProduct As Double
        Dim dblTickets As Double
        Dim dblPrice As Double
        Dim dblSubtotal As Double
        Dim dblTax As Double
        Dim dblTotalProduct As Double
        Dim dblTotal As Double
        Dim dblRunningDailyGrandTotal As Double
        Dim dblPromotersProfit As Double
        'this is the promoters profit variable'
        Dim dblProfit As Double
        'calculates subtotal

        dblPrice = txtPriceOfTickets.Text
        dblTickets = txtNumberOFTIckets.Text
        dblSubtotalProduct = dblPrice * dblTickets
        LblSubtotal.Text = dblSubtotalProduct
        'calculates tax'

        dblTax = 0.07
        dblSubtotal = LblSubtotal.Text
        dblTotalProduct = dblTax * dblSubtotal
        LblTax.Text = dblTotalProduct

        'calculate total'
        dblTotal = dblTotalProduct + dblSubtotal
        LblTotal.Text = dblTotal
        'calculate daily grand total '
        'dblRunningDailyGrandTotal = dblRunningDailyGrandTotal + dblSubtotal'
        dblRunningDailyGrandTotal = dblRunningDailyGrandTotal + dblSubtotalProduct
        LblDailyGrandTotal.Text = dblRunningDailyGrandTotal

        'calculate promoters profit'
        dblProfit = 0.2
        dblPromotersProfit = dblRunningDailyGrandTotal * dblProfit
        LblPromotersProfit.Text = dblPromotersProfit

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'clears all fields'
        txtNumberOFTIckets.Clear()
        txtPriceOfTickets.Clear()
        LblSubtotal.ResetText()
        LblTax.ResetText()
        LblTotal.ResetText()
        LblDailyGrandTotal.ResetText()
        LblPromotersProfit.ResetText()

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'closes program'
        Close()

    End Sub
End Class
